  #include<stdio.h>
int main()
{
  int n,a=3;
    scanf("%d",&n);
  while(n--)
  {
    printf("%d ",a);
    a*=3;
  }
  
  return 0;
}