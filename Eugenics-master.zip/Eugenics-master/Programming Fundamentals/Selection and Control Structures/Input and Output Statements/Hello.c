 #include<stdio.h>
int main()
{
 printf("Hello Aliens ! Welcome to our planet Earth.\n"); 
  
  
  
  return 0;
}