  #include<stdio.h>
int main()
{
    int a;
  scanf("%d",&a);
    if(a%2==0)
      printf("yes\n");
  else if (a%3==0)
    printf("yes\n");
    else
      printf("no\n");
  
  
  return 0;
}