  #include<stdio.h>
int main()
{
    int a,b;
  printf("Enter the number of students in college 1\n");
  scanf("%d",&a);
  printf("Enter the number of students in college 2\n");
  scanf("%d",&b);
  if(a>b)
    printf("College 1 is better\n");
  else 
    printf("College 2 is better\n");
  
  
  return 0;
}